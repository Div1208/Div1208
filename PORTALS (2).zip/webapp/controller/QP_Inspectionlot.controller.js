sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast"
], function(Controller, MessageToast) {
	"use strict";

	return Controller.extend("divyarPORTALS.controller.QP_Inspectionlot", {
		onInit: function() {
			var service = "/sap/opu/odata/sap/ZQM_ODATA_DIVYA_R_SRV/";

			var oModel = new sap.ui.model.odata.ODataModel(service, true);

			var uri = "?$filter=Plant eq '0001'";
			var no;
			oModel.read("/ZDR_INSPECTLISTSet" + uri, {
				context: null,
				urlParameters: null,
				async: false,
				success: function(oData, oResponse) {

					no = oData.results;
				}
			});
			var ooModel = new sap.ui.model.json.JSONModel(no);
			this.getView().setModel(ooModel, "insp_list");
		},
		onclickL: function() {
		      	var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("HomePage");
				MessageToast.show("You have successfully logged out!");
		},
		_getDialog: function() {
			if (!this._oDialog) {
				this._oDialog = sap.ui.xmlfragment("divyarPORTALS.view.Fragments.inspectionlot", this);
				this.getView().addDependent(this._oDialog);
			}
			return this._oDialog;
		},
		displaydetails_insp: function(oEvent) {
			this._getDialog().open();
			var objcurrent = oEvent.getSource().getSelectedContexts()[0].getObject();
			window.console.log(objcurrent);
			var service = "/sap/opu/odata/sap/ZQM_ODATA_DIVYA_R_SRV";
			var oModel = new sap.ui.model.odata.ODataModel(service, true); //NOTIFICATION
			var uri = "(InsplotNumber='" + objcurrent.Orderid + "')";
			window.console.log(uri);
			//	ZPM_MAINTENANCE_HARSHINI_C_SRV/ZH_NO_DETAILSSet(NotiNumber='10000113')

			oModel.read("/ZDR_INSPECTDETSet" + uri, {
				context: null,
				urlParameters: null,
				async: false,
				success: function(oData, oResponse) {

				}
			});

			var ooModel1 = new sap.ui.model.json.JSONModel(objcurrent);
			window.console.log(ooModel1);
			this._oDialog.setModel(ooModel1);

		},
		onClose1: function() {
			this._getDialog().close();
		}

		
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf divyarPORTALS.view.QP_Inspectionlot
		 */
		//	onInit: function() {
		//
		//	},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf divyarPORTALS.view.QP_Inspectionlot
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf divyarPORTALS.view.QP_Inspectionlot
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf divyarPORTALS.view.QP_Inspectionlot
		 */
		//	onExit: function() {
		//
		//	}

	});

});