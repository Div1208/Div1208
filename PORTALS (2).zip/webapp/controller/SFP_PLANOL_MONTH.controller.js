sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast"
], function(Controller, JSONModel,MessageToast) {
	"use strict";

	return Controller.extend("divyarPORTALS.controller.SFP_PLANOL_MONTH", {
		onclick: function() {
			var month = this.getView().byId("month").getSelectedKey('SelectedMonth');
			window.console.log(month);
			var year = this.getView().byId("Year").getValue();
			var service = "/sap/opu/odata/sap/ZSFP_ODATA_DR_SRV";
			var oModel = new sap.ui.model.odata.ODataModel(service, true);
			window.console.log(oModel);
			var uri = "?$filter=Plant eq '0001' and MrpCtrl eq '001' and FilterType eq 'MONTH' and FilterValue eq '" + month + "' and Year eq '" + year + "'";
			window.console.log(uri);
			var no;
			oModel.read("/ZDR_PLAN_OLSet" + uri, {
				context: null,
				urlParameters: null,
				async: false,
				success: function(oData, oResponse) {
					no = oData.results;
				}
			});

			var ooModel = new sap.ui.model.json.JSONModel(no);
			this.getView().setModel(ooModel, "planorderlist_month");

		},

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf divyarPORTALS.view.SFP_PLANOL_MONTH
		 */
		onInit: function() {

			var oData = {
				"SelectedMonth": "1",
				"MonthCollection": [{
					"MonthId": "1",
					"Name": "January"
				}, {
					"MonthId": "2",
					"Name": "February"
				}, {
					"MonthId": "3",
					"Name": "March"
				}, {
					"MonthId": "4",
					"Name": "April"
				}, {
					"MonthId": "5",
					"Name": "May"
				}, {
					"MonthId": "6",
					"Name": "June"
				}, {
					"MonthId": "7",
					"Name": "July"
				}, {
					"MonthId": "8",
					"Name": "August"
				}, {
					"MonthId": "9",
					"Name": "September"
				}, {
					"MonthId": "10",
					"Name": "October"
				}, {
					"MonthId": "11",
					"Name": "November"
				}, {
					"MonthId": "12",
					"Name": "December"
				}]
			};

			// set explored app's demo model on this sample
			var oModel = new JSONModel(oData);
			this.getView().setModel(oModel);

		},
			_getDialog: function() {
			if (!this._oDialog) {
				this._oDialog = sap.ui.xmlfragment("divyarPORTALS.view.Fragments.planorderdetails", this);
				this.getView().addDependent(this._oDialog);
			}
			return this._oDialog;
		},
		displaydetails_plan: function(oEvent) {
			this._getDialog().open();
			var objcurrent = oEvent.getSource().getSelectedContexts()[0].getObject();
			window.console.log(objcurrent);
			var service = "/sap/opu/odata/sap/ZSFP_ODATA_DR_SRV";
			var oModel = new sap.ui.model.odata.ODataModel(service, true); 
			var uri = "(PlanorderNumber='" + objcurrent.Orderid + "')";
			window.console.log(uri);
			

			oModel.read("/ZDR_PLAN_ODSet" + uri, {
				context: null,
				urlParameters: null,
				async: false,
				success: function(oData, oResponse) {

				}
			});

			var ooModel1 = new sap.ui.model.json.JSONModel(objcurrent);
			window.console.log(ooModel1);
			this._oDialog.setModel(ooModel1);
		},
		onClose: function() {
			this._getDialog().close();
		},
		onclickL: function() {
		      	var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("HomePage");
				MessageToast.show("You have successfully logged out!");
		}


		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf divyarPORTALS.view.SFP_PLANOL_MONTH
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf divyarPORTALS.view.SFP_PLANOL_MONTH
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf divyarPORTALS.view.SFP_PLANOL_MONTH
		 */
		//	onExit: function() {
		//
		//	}

	});

});