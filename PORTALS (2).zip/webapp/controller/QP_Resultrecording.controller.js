sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast"
], function(Controller,MessageToast) {
	"use strict";

	return Controller.extend("divyarPORTALS.controller.QP_Resultrecording", {
		onInit: function() {
			var service = "/sap/opu/odata/sap/ZQM_ODATA_DIVYA_R_SRV/";

			var oModel = new sap.ui.model.odata.ODataModel(service, true);

			var uri = "?$filter=Plant eq '0001'";
			var no;
			oModel.read("/ZDR_RESULTRECSet" + uri, {
				context: null,
				urlParameters: null,
				async: false,
				success: function(oData, oResponse) {

					no = oData.results;
				}
			});
			var ooModel = new sap.ui.model.json.JSONModel(no);
			this.getView().setModel(ooModel, "res_rec");
		},
		onclickL: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("HomePage");
			MessageToast.show("You have successfully logged out!");
		},
		_getDialog: function() {
			if (!this._oDialog) {
				this._oDialog = sap.ui.xmlfragment("divyarPORTALS.view.Fragments.resultrec", this);
				this.getView().addDependent(this._oDialog);
			}
			return this._oDialog;
		},
		displaydetails_resrec: function(oEvent) {
			this._getDialog().open();
			var objcurrent = oEvent.getSource().getSelectedContexts()[0].getObject();
			var mat = new sap.ui.model.json.JSONModel(objcurrent);
			this._oDialog.setModel(mat);
		},
		onClose: function() {
			this._getDialog().close();
		}

		

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf divyarPORTALS.view.QP_Resultrecording
		 */
		//	onInit: function() {
		//
		//	},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf divyarPORTALS.view.QP_Resultrecording
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf divyarPORTALS.view.QP_Resultrecording
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf divyarPORTALS.view.QP_Resultrecording
		 */
		//	onExit: function() {
		//
		//	}

	});

});